import tkinter as tk
from random import *
from tkinter import messagebox
root = tk.Tk()
root.title('Dice Simulator')
root.resizable(0,0)
canvas1 = tk.Canvas(width=300, height=300, bg='gray45', relief='ridge', bd='12')
canvas1.pack()
diceSimlab = tk.Label(text='Dice Simulator!', font=('Comic Sans MS', 16, 'bold'), bg='gray35', fg='black', relief='sunken', bd='6')
canvas1.create_window(165, 285, window=diceSimlab)

with open('dicelog.txt', 'w') as file:
    file.write('[log gets overwritten every time the simulator is opened]\n\nStart\n\n')

canvas2 = tk.Canvas(canvas1, width=200, height=130, bg='gray35', relief='ridge', bd='12')
canvas2.pack()
canvas1.create_window(165,105,window=canvas2)

diceShown = {'diceShown1' : False}

roll1 = tk.PhotoImage(file='imgs/dice_1.ppm')
roll2 = tk.PhotoImage(file='imgs/dice_2.ppm')
roll3 = tk.PhotoImage(file='imgs/dice_3.ppm')
roll4 = tk.PhotoImage(file='imgs/dice_4.ppm')
roll5 = tk.PhotoImage(file='imgs/dice-5.ppm')
roll6 = tk.PhotoImage(file='imgs/dice-6.ppm')

rollImgs = [roll1, roll2, roll3, roll4, roll5, roll6]

def rolled():
    if diceShown['diceShown1'] == False:
        diceShown['diceShown1'] = True
        diceRoll = randint(0,5)
        diceNumber = diceRoll + 1
        with open('dicelog.txt', 'a') as file:
            file.write(f'rolled {diceNumber} \n')
            canvas2.create_text(150, 70, text=diceNumber, font=('Arial', 20, 'bold'))
        canvas2.create_image(105, 75, image=(rollImgs[diceRoll]))
    else:
        tk.messagebox.showerror(title='Roll Error', message='[Error: You need to reset before rolling again!]')
        with open('dicelog.txt', 'a') as file:
            file.write('Error_1 returned\n')

def resetD():
    diceShown['diceShown1'] = False
    canvas2.delete('all')

reset = tk.Button(root, width='4', height='1', text='Reset', command=resetD, font=('Impact', 13, 'normal'), fg='white', bg='red', highlightcolor='white', activebackground='red', activeforeground='white', relief='raised', bd='5')
canvas1.create_window(80, 225, window=reset)
rollDice = tk.Button(root, width='6', height='1', text='Roll!', command=rolled, font=('Impact', 18, 'bold'), fg='white', bg='red', highlightcolor='white', activebackground='red', activeforeground='white', relief='raised', bd='5')
canvas1.create_window(165, 225, window=rollDice)

root.mainloop()